// src/main/resources/static/js/loadAddress.js

;(function() {
  /**
   * 서버에서 주소 리스트를 가져와
   * 지도(map) 위에 마커로 찍어주고
   * bounds 를 조정하는 함수
   */
  window.loadAddresses = function() {
    const map      = window.kakaoMap;
    const geocoder = window.kakaoGeocoder;
    //const bounds   = new kakao.maps.LatLngBounds();

    fetch('/post/addresses/list')
      .then(res => {
        if (!res.ok) throw new Error('네트워크 오류: ' + res.status);
        return res.json();
      })
      .then(addresses => {
        addresses.forEach(addr => {
          geocoder.addressSearch(addr, (result, status) => {
            if (status === kakao.maps.services.Status.OK) {
              const coords = new kakao.maps.LatLng(result[0].y, result[0].x);
              new kakao.maps.Marker({
                map: map,
                position: coords,
                title: addr
              });
              //bounds.extend(coords);
              //
              //map.setBounds(bounds);
            } else {
              console.warn(`주소 검색 실패 (${addr}):`, status);
            }
          });
        });
      })
      .catch(err => {
        console.error('주소 리스트 로드 중 에러', err);
      });
  };
})();
