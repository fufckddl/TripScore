package com.example.demo.reservation.entity;

import com.example.demo.post.entity.Post;
import com.example.demo.user.entity.SiteUser;
import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private SiteUser requester;  // 요청자

    @ManyToOne
    @JoinColumn(name = "post_id", foreignKey = @ForeignKey(name = "fk_reservation_post"))
    private Post post;

    @Enumerated(EnumType.STRING)
    private Status status;  // PENDING, ACCEPTED, REJECTED

    @Column(nullable = false)
    private LocalDateTime requestDate;

    @Column(name = "accepted_date")
    private LocalDateTime acceptedDate;

    @PrePersist
    public void preUpdate(){
         requestDate = LocalDateTime.now();
    }

    public enum Status {
        PENDING, ACCEPTED, REJECTED //대기, 수락, 거절
    }
}
