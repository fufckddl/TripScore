package com.example.demo.post.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostImageDto {

    @NotNull
    private Long postId;

    @NotNull
    private String url;
}
