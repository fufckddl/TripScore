// src/main/resources/static/js/Geocoder.js

;(function() {
  // 지도 초기화와 숙소 리스트 마커 찍기
  window.initMap = function() {
    // 1) 지도 생성
    const map = new kakao.maps.Map(
      document.getElementById('map'),
      {
        center: new kakao.maps.LatLng(37.5665, 126.9780),
        level: 4
      }
    );

    // 2) 주소 → 좌표 변환 서비스
    const geocoder = new kakao.maps.services.Geocoder();

    // 3) 전역에 저장 (다른 스크립트에서 재사용 가능)
    window.kakaoMap       = map;
    window.kakaoGeocoder  = geocoder;

    // 4) Thymeleaf가 바인딩한 주소 배열
    const addresses = window.addresses || [];

    // 5) 모든 마커를 포함할 LatLngBounds
    const bounds = new kakao.maps.LatLngBounds();

    if (typeof window.loadAddresses === 'function') {
          window.loadAddresses();
        }
  };
})();
