document.addEventListener('DOMContentLoaded', function () {
  const hamburger = document.getElementById('hamburger');
  const menu = document.getElementById('menu');
  const closeBtn = document.getElementById('closeBtn');
  const body = document.body;

  hamburger.addEventListener('click', () => {
    menu.classList.add('open');
    body.classList.add('menu-open');
  });

  closeBtn.addEventListener('click', () => {
    menu.classList.remove('open');
    body.classList.remove('menu-open');
  });
});
