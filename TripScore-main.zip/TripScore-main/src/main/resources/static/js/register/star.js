/*<![CDATA[*/
  document.addEventListener('DOMContentLoaded', function() {
    const stars = document.querySelectorAll('.star-rating .star');
    const input  = document.getElementById('rating-value');
    const form   = document.getElementById('comment-form');

    // 페이지 로드 시, 이미 선택된 값이 있으면 별 표시
    updateStars(parseInt(input.value) || 0);

    stars.forEach(star => {
      const val = parseInt(star.dataset.value);
      star.addEventListener('click', () => {
        input.value = val;
        updateStars(val);
      });
      star.addEventListener('mouseover', () => updateStars(val));
      star.addEventListener('mouseout',  () => updateStars(parseInt(input.value) || 0));
    });

    form.addEventListener('submit', function(e) {
      if (!input.value || parseInt(input.value) < 1) {
        e.preventDefault();
        alert('댓글을 작성하시려면 먼저 별점을 선택해주세요!');
      }
    });

    function updateStars(rating) {
      stars.forEach(s => {
        s.textContent = (parseInt(s.dataset.value) <= rating) ? '★' : '☆';
      });
    }
  });
  /*]]>*/