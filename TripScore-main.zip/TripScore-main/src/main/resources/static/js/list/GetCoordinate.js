;(function() {
  window.getCoordinate = function(address = '서울특별시 강남구 역삼동 736-28') {
    const map      = window.kakaoMap;       // Geocoder.js 에서 세팅된 지도
    const geocoder = window.kakaoGeocoder;  // Geocoder.js 에서 세팅된 Geocoder

    geocoder.addressSearch(address, (result, status) => {
      if (status === kakao.maps.services.Status.OK) {
        const { x, y } = result[0];
        console.log('위도:', y, '경도:', x);

        // 기존 map 객체만 사용해서 중심 이동
        map.setCenter(new kakao.maps.LatLng(y, x));
        map.setLevel(3);

        // 필요하면 마커 추가
        new kakao.maps.Marker({
          map: map,
          position: new kakao.maps.LatLng(y, x),
          title: address
        });
      } else {
        console.error('주소 검색 실패:', status);
      }
    });
  };
})();
