// src/main/resources/static/js/CitySearch.js

;(function() {
  document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('searchButton');
    btn.addEventListener('click', e => {
      e.preventDefault();
      const prov = document.getElementById('provinceDropdown').value;
      const city = document.getElementById('cityDropdown').value;
      const town = document.getElementById('townDropdown').value;
      if (!prov || !city || !town) {
        alert('도/시/읍|면을 모두 선택해주세요.');
        return;
      }
      const address = prov + ' ' + city + ' ' + town;
      console.log('검색 주소:', address);

      // 전역에서 꺼내 쓰기
      const geocoder = window.kakaoGeocoder;
      const map       = window.kakaoMap;

      geocoder.addressSearch(address, (result, status) => {
        if (status === kakao.maps.services.Status.OK) {
          const loc = new kakao.maps.LatLng(result[0].y, result[0].x);
          map.setCenter(loc);
          // (선택) 검색 마커
          new kakao.maps.Marker({ map, position: loc, title: address });
        } else {
          alert('주소를 찾을 수 없습니다.');
        }
      });
    });
  });
})();
