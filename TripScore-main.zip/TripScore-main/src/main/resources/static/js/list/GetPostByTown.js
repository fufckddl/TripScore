function handleTownChange() {
  const town = document.getElementById("townDropdown").value;

  if (!town) return;

  fetch(`/post/search?town=${encodeURIComponent(town)}`)
    .then(res => res.json())
    .then(data => {
      renderPostList(data);
    })
    .catch(err => {
      console.error("숙소 목록 가져오기 실패:", err);
    });
}

function renderPostList(posts) {
  const container = document.getElementById("postListContainer");
  container.innerHTML = '';

  if (posts.length === 0) {
    container.innerHTML = "<p>해당 지역에 숙소가 없습니다.</p>";
    return;
  }

  const ul = document.createElement("ul");
  posts.forEach(post => {
    const li = document.createElement("li");
    li.innerHTML = `
          <a href="/post/detail/${post.id}" style="text-decoration: none; color: inherit;">
            <strong>${post.title}</strong><br>${post.address}
          </a>
        `;
    ul.appendChild(li);
  });
  container.appendChild(ul);
}
