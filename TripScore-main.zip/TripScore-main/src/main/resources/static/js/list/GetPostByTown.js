document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('searchButton')
    .addEventListener('click', fetchPostsByTown);
});

// 1) 숙소 목록 가져오기 + 렌더링, 2) 지도를 선택된 읍/면으로 이동
function fetchPostsByTown() {
  const town = document.getElementById('townDropdown').value;
  if (!town) return;
  fetch(`/post/search?town=${encodeURIComponent(town)}`)
    .then(res => res.json())
    .then(data => {
      renderPostList(data);
      geocodeTown(town);    // 지도 이동 호출
    })
    .catch(err => console.error('숙소 목록 가져오기 실패:', err));
}

// 지정된 주소(읍/면)에 맞춰 카카오맵 센터 이동
function geocodeTown(address) {
  const geocoder = new kakao.maps.services.Geocoder();
  geocoder.addressSearch(address, (result, status) => {
    if (status === kakao.maps.services.Status.OK) {
      const coords = new kakao.maps.LatLng(result[0].y, result[0].x);
      if (window.kakaoMap) {
        window.kakaoMap.setCenter(coords);
      }
    }
  });
}

// 숙소 리스트 렌더링
function renderPostList(posts) {
  const container = document.getElementById('postListContainer');
  container.innerHTML = '';
  if (!posts.length) {
    container.innerHTML = '<p>해당 지역에 숙소가 없습니다.</p>';
    return;
  }
  const ul = document.createElement('ul');
  posts.forEach(post => {
    const li = document.createElement('li');
    li.innerHTML = `
      <a href="/post/detail/${post.id}">
        <strong>${post.title}</strong><br>
        <span>${post.address}</span>
      </a>
    `;
    ul.appendChild(li);
  });
  container.appendChild(ul);
}