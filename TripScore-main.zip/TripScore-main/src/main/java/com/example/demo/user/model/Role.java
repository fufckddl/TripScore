package com.example.demo.user.model;

public enum Role {
    USER,
    ADMIN
}
