package com.example.demo.reservation.dto;

import com.example.demo.reservation.entity.Reservation;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReservationDto {
    private Reservation reservation;
    private boolean canWriteComment; //2일 뒤 쓸수있는지 없는지 0/1
}

