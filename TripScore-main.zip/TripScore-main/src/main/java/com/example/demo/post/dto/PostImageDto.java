package com.example.demo.post.dto;

import com.example.demo.post.entity.Post;
import com.example.demo.user.entity.SiteUser;
import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostImageDto {

    private String url;

}
