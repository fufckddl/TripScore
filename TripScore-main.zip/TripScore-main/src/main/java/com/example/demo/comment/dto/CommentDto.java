package com.example.demo.comment.dto;

import com.example.demo.comment.entity.Comment;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentDto {

    private Long id;

    @NotNull
    private Long postId;

    private Long parentCommentId;

    @NotBlank(message = "내용은 필수입니다.")
    @Size(min = 2, max = 300, message = "내용은 2~300자여야 합니다.")
    private String comment;

    @NotNull
    private double evaluate;
}
