package com.example.demo.comment.repository;

import com.example.demo.comment.entity.Comment;
import com.example.demo.post.entity.Post;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByPostId(Long postId);
    void deleteByPost(Post post);
    List<Comment> findByParentComment(Comment parentComment);
}
