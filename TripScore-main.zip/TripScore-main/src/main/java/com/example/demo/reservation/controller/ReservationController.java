package com.example.demo.reservation.controller;

import com.example.demo.reservation.entity.Reservation;
import com.example.demo.reservation.repository.ReservationRepository;
import com.example.demo.post.entity.Post;
import com.example.demo.post.service.PostService;
import com.example.demo.user.security.SiteUserDetails;
import com.example.demo.user.entity.SiteUser;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class ReservationController {

    private final PostService postService;
    private final ReservationRepository reservationRepository;

    @PostMapping("/reservation/request/{postId}")
    public String requestReservation(@PathVariable Long postId,
                                     @AuthenticationPrincipal SiteUserDetails userDetails) {
        SiteUser user = userDetails.getUser();
        Post post = postService.findById(postId);

        if (reservationRepository.existsByPostAndRequesterAndStatus(post, user, Reservation.Status.PENDING)) {
            return "redirect:/post/detail/" + postId + "?alreadyRequested=true";
        }

        Reservation reservation = new Reservation();
        reservation.setPost(post);
        reservation.setRequester(user);
        reservation.setStatus(Reservation.Status.PENDING);
        reservationRepository.save(reservation);

        return "redirect:/post/detail/" + postId;
    }

    @GetMapping("/reservation/request/{postId}")
    public String rejectDirectGet() {
        return "redirect:/post/list"; // 또는 에러 페이지로 유도
    }

    @GetMapping("/reservation/inbox")
    public String viewReservationInbox(@AuthenticationPrincipal SiteUserDetails userDetails, Model model) {
        SiteUser author = userDetails.getUser();
        List<Reservation> incomingRequests = reservationRepository.findByPost_SiteUserAndStatus(author, Reservation.Status.PENDING);
        model.addAttribute("reservations", incomingRequests);
        return "reservation/inbox";
    }

    @PostMapping("/reservation/accept/{reservationId}")
    public String acceptReservation(@PathVariable Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId).orElseThrow();
        reservation.setStatus(Reservation.Status.ACCEPTED);
        Long requesterId = reservation.getRequester().getId();
        reservationRepository.save(reservation);
        return "redirect:/";
    }

    @PostMapping("/reservation/reject/{reservationId}")
    public String rejectReservation(@PathVariable Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId).orElseThrow();
        reservation.setStatus(Reservation.Status.REJECTED);
        reservationRepository.save(reservation);
        return "redirect:/";
    }
    @GetMapping("/reservation/button/{postId}")
    @ResponseBody
    public boolean canRequestReservation(@PathVariable Long postId, @AuthenticationPrincipal SiteUserDetails userDetails) {
        SiteUser user = userDetails.getUser();
        Post post = postService.findById(postId);
        return !reservationRepository.existsByPostAndRequesterAndStatus(post, user, Reservation.Status.PENDING);
    }
}
