package com.example.demo.reservation.service;

import com.example.demo.post.dto.PostDto;
import com.example.demo.post.entity.Post;
import com.example.demo.post.service.PostService;
import com.example.demo.reservation.entity.Reservation;
import com.example.demo.reservation.repository.ReservationRepository;
import com.example.demo.user.entity.SiteUser;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Service;

@Service
@Getter
@Setter
@RequiredArgsConstructor
public class ReservationService {
    private final PostService postService;
    private final ReservationRepository reservationRepository;

    public void addReservation(Long id, SiteUser siteUser){
        Post post = postService.findById(id);
        Reservation reservation = new Reservation();
        reservation.setPost(post);
        reservation.setRequester(siteUser);
        reservation.setStatus(Reservation.Status.PENDING);
        reservationRepository.save(reservation);
    }

}
