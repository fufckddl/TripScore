package com.example.demo.post.controller;

import com.example.demo.post.dto.PostDto;
import com.example.demo.post.dto.PostImageDto;
import com.example.demo.post.entity.Post;
import com.example.demo.post.entity.PostImage;
import com.example.demo.post.service.PostService;
import com.example.demo.user.security.SiteUserDetails;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Controller
@RequestMapping("/post")
public class PostController {

    private final PostService postService;

    @Value("${kakao.js-key}")
    private String kakaoJsKey;


    @Value("${file.upload-dir}")
    private String uploadDir;


    @GetMapping("/list")
    public String map(Model model) {
        model.addAttribute("appKey", kakaoJsKey);

        // db에서 숙조 전부 마커로 표시할거임
        List<String> addresses = List.of(
                "서울특별시 중구 세종대로 110"
        );
        model.addAttribute("addresses", addresses);

        return "post/list";
    }

    @GetMapping("/search")
    @ResponseBody
    public List<PostDto> searchByTown(@RequestParam String town)
    {
        return postService.findByTownContaining(town)
                .stream()
                .map(PostDto::fromEntity)
                .collect(Collectors.toList());
    }

    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Long id, Model model)
    {
        Post post = postService.findById(id);
        model.addAttribute("post", post);
        return "post/detail";
    }


    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("appKey", kakaoJsKey);

        // 초기 위치
        List<String> addresses = List.of(
                "서울특별시 중구 세종대로 110"
        );
        model.addAttribute("addresses", addresses);


        return "post/register";
    }

    @PostMapping("/create")
    public String create(@RequestParam("file") MultipartFile file,
                         RedirectAttributes redirectAttributes,
                         @Valid @ModelAttribute PostDto postDto,
                         @Valid @ModelAttribute PostImageDto postImgDto,
                         BindingResult bindingResult,
                         @AuthenticationPrincipal SiteUserDetails siteUserDetails,
                         Model model) {
        if (bindingResult.hasErrors()) {
            List<String> addresses = List.of(
                    "서울특별시 중구 세종대로 110"
            );
            model.addAttribute("appKey", kakaoJsKey);
            model.addAttribute("addresses", addresses);
            model.addAttribute("postDto", postDto);
            System.out.println(bindingResult.getAllErrors());

            return "post/register";
        }

        if (file.isEmpty()) {
            System.out.println("empty");
            redirectAttributes.addFlashAttribute("message", "파일을 선택해주세요.");
            return "redirect:/";
        }

        try {
            // 절대 경로로 폴더 생성
            File uploadPath = new File(uploadDir).getAbsoluteFile();
            if (!uploadPath.exists()) uploadPath.mkdirs();

            // 특수문자 제거 (윈도우에서 저장 불가한 문자 방지)
            String cleanedName = file.getOriginalFilename().replaceAll("[^a-zA-Z0-9._-]", "_");

            // 실제 저장
            File saveFile = new File(uploadPath, cleanedName);
            file.transferTo(saveFile);

            System.out.println("success");
            redirectAttributes.addFlashAttribute("message", "업로드 성공: " + cleanedName);
        } catch (IOException e) {
            System.out.println("fail");
            e.printStackTrace();  // 콘솔에 상세 에러 출력
            redirectAttributes.addFlashAttribute("message", "업로드 실패: " + e.getMessage());
        }


        if (siteUserDetails == null)
            return "redirect:/user/login";

        //포스트이미지 url저장해야됨
        postService.uploadImage(postImgDto);
        postService.create(postDto, siteUserDetails.getUser());
        return "redirect:/";
    }


    @ResponseBody
    @GetMapping("/addresses")
    public List<String> getAllAddresses() {
        return postService.fetchAllAddress();
    }
    @ResponseBody
    @GetMapping("/addresses/title")
    public List<String> getAllTitles(){
        return postService.fetchAllTitle();
    }
}

