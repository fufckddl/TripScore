package com.example.demo.post.controller;

import com.example.demo.comment.dto.CommentDto;
import com.example.demo.comment.entity.Comment;
import com.example.demo.comment.repository.CommentRepository;
import com.example.demo.comment.service.CommentService;
import com.example.demo.post.dto.PostDto;
import com.example.demo.post.dto.PostImageDto;
import com.example.demo.post.entity.Post;
import com.example.demo.post.entity.PostImage;
import com.example.demo.post.repository.PostImageRepository;
import com.example.demo.post.service.PostService;
import com.example.demo.user.security.SiteUserDetails;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Controller
@RequestMapping("/post")
public class PostController {

    private final PostService postService;
    private final PostImageRepository postImageRepository;
    private final CommentService commentService;
    private final CommentRepository commentRepository;

    @Value("${kakao.js-key}")
    private String kakaoJsKey;


    @Value("${file.upload-dir}")
    private String uploadDir; //사진 업로드될 폴더 이름


    @GetMapping("/list")
    public String map(Model model) {
        model.addAttribute("appKey", kakaoJsKey);

        // db에서 숙조 전부 마커로 표시할거임
        List<String> addresses = List.of(
                "서울특별시 중구 세종대로 110"
        );
        model.addAttribute("addresses", addresses);

        return "post/list";
    }

    @GetMapping("/search")
    @ResponseBody
    public List<PostDto> searchByTown(@RequestParam String town)
    {
        return postService.findByTownContaining(town)
                .stream()
                .map(PostDto::fromEntity)
                .collect(Collectors.toList());
    }

    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Long id, Model model)
    {
        Post post = postService.findById(id);
        List<Comment> comments = commentRepository.findByPostId(id);

        CommentDto cmtDto = new CommentDto();
        cmtDto.setPostId(post.getId());  // 여기서 postId를 미리 설정합니다.
        cmtDto.setParentComment(cmtDto.getId());
        model.addAttribute("comments", comments);
        model.addAttribute("cmtDto", cmtDto);
        model.addAttribute("post", post);
        
        List<PostImage> imageList = postImageRepository.findByPostId(id); // postid를 찾아서 poistimage를 리스트형태로 변환해서 넘겨주기
        model.addAttribute("imageList", imageList);
        return "post/detail";
    }


    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("appKey", kakaoJsKey);

        // 초기 위치
        List<String> addresses = List.of(
                "서울특별시 중구 세종대로 110"
        );
        model.addAttribute("addresses", addresses);


        return "post/register";
    }

    @PostMapping("/create")
    public String create(@RequestParam("file") MultipartFile[] files,
                         RedirectAttributes redirectAttributes,
                         @Valid @ModelAttribute PostDto postDto,
                         BindingResult bindingResult,
                         @AuthenticationPrincipal SiteUserDetails siteUserDetails,
                         Model model) {
        if (siteUserDetails == null)
            return "redirect:/user/login";

        if (bindingResult.hasErrors()) {
            List<String> addresses = List.of(
                    "서울특별시 중구 세종대로 110"
            );
            model.addAttribute("appKey", kakaoJsKey);
            model.addAttribute("addresses", addresses);
            model.addAttribute("postDto", postDto);
            System.out.println(bindingResult.getAllErrors());

            return "post/register";
        }

        if (files == null || files.length == 0 || files[0].isEmpty()) {
            System.out.println("empty");
            redirectAttributes.addFlashAttribute("message", "파일을 선택해주세요.");
            return "redirect:/";
        }

        try {
            // 절대 경로로 폴더 생성
            File uploadPath = new File(uploadDir + "/" + siteUserDetails.getUser().getId()).getAbsoluteFile();
            if (!uploadPath.exists()) uploadPath.mkdirs();

            // 특수문자 제거 (윈도우에서 저장 불가한 문자 방지)
            //String cleanedName = file.getOriginalFilename().replaceAll("[^a-zA-Z0-9._-]", "_");
            Post savedPost = postService.create(postDto, siteUserDetails.getUser());

            for(int i = 0; i < files.length; i++)
            {
                MultipartFile file = files[i];
                if(file.isEmpty()) continue;
                String originalName = file.getOriginalFilename();
                String ext = originalName.substring(originalName.lastIndexOf("."));

                String newName = "user" + "_" + siteUserDetails.getUser().getId() + "_" + i + ext;
                // 실제 저장
                File saveFile = new File(uploadPath, newName);
                file.transferTo(saveFile);
                PostImageDto postImgDto = new PostImageDto();
                String fileUrl = "/uploads/" + siteUserDetails.getUser().getId() + "/" + newName;
                postImgDto.setUrl(fileUrl);
                postImgDto.setPostId(savedPost.getId());
                System.out.println("success");
                redirectAttributes.addFlashAttribute("message", "업로드 성공: " + newName);
                postService.uploadImage(postImgDto, siteUserDetails.getUser(), savedPost);
            }
        } catch (IOException e) {
            System.out.println("fail");
            e.printStackTrace();  // 콘솔에 상세 에러 출력
            redirectAttributes.addFlashAttribute("message", "업로드 실패: " + e.getMessage());
        }
        return "redirect:/";
    }


    @ResponseBody
    @GetMapping("/addresses")
    public List<String> getAllAddresses() {
        return postService.fetchAllAddress();
    }
    @ResponseBody
    @GetMapping("/addresses/title")
    public List<String> getAllTitles(){
        return postService.fetchAllTitle();
    }
}

