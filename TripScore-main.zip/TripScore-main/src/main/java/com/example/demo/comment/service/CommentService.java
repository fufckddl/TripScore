package com.example.demo.comment.service;

import com.example.demo.comment.dto.CommentDto;
import com.example.demo.comment.entity.Comment;
import com.example.demo.comment.repository.CommentRepository;
import com.example.demo.post.entity.Post;
import com.example.demo.post.service.PostService;
import com.example.demo.user.entity.SiteUser;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class CommentService {
    private final PostService postService;
    private final CommentRepository commentRepository;
    @Transactional
    public void createComment(CommentDto dto, SiteUser user)
    {
        Post post = postService.findById(dto.getPostId());

        Comment comment = new Comment();
        comment.setComment(dto.getComment());
        comment.setSiteUser(user);
        comment.setPost(post);
        if (dto.getParentCommentId() != null) {
            Comment parent = commentRepository.findById(dto.getParentCommentId())
                    .orElseThrow(() -> new IllegalArgumentException("부모 댓글이 존재하지 않습니다."));
            comment.setParentComment(parent);
        }

        commentRepository.save(comment);
    }
    public void deleteComment(Long id){
        commentRepository.deleteById(id);
    }
    public List<Comment> getCommentsByPostId(Long postId) {
        // Free 엔티티를 기준으로 댓글을 조회하거나, 직접 쿼리를 날려 가져올 수 있습니다.
        return commentRepository.findByPostId(postId);
    }
    public Comment getCommentId(Long id)
    {
        return commentRepository.findById(id).orElseThrow(()-> new RuntimeException("댓글을 찾을 수 없습니다."));
    }
}
