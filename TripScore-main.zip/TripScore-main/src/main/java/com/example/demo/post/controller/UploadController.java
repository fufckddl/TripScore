package com.example.demo.post.controller;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
public class UploadController {

    @GetMapping("/uploads/{folder}/{filename:.+}")
    public ResponseEntity<Resource> getImage(
            @PathVariable String folder,
            @PathVariable String filename) throws MalformedURLException {

        Path path = Paths.get("uploads", folder, filename);  // 프로젝트 루트 기준
        System.out.println("🔍 요청된 경로: " + path.toAbsolutePath());

        boolean fileExists = Files.exists(path);
        System.out.println("✅ 파일 존재 여부: " + fileExists);

        if (!fileExists) {
            System.out.println("❌ 파일 없음: " + path);
            return ResponseEntity.notFound().build();
        }

        Resource resource = new UrlResource(path.toUri());

        return ResponseEntity.ok()
                .contentType(MediaTypeFactory.getMediaType(resource)
                        .orElse(MediaType.APPLICATION_OCTET_STREAM))
                .body(resource);
    }
}
