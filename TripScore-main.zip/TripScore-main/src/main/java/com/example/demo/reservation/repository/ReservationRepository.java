package com.example.demo.reservation.repository;

import com.example.demo.reservation.entity.Reservation;
import com.example.demo.post.entity.Post;
import com.example.demo.user.entity.SiteUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    boolean existsByPostAndRequesterAndStatus(Post post, SiteUser requester, Reservation.Status status);

    List<Reservation> findByPost(Post post);

    List<Reservation> findByRequester(SiteUser requester);

    Optional<Reservation> findByPostAndRequester(Post post, SiteUser requester);

    List<Reservation> findByPost_SiteUserAndStatus(SiteUser author, Reservation.Status status);

}
