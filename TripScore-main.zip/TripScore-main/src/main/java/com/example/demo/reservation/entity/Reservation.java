package com.example.demo.reservation.entity;

import com.example.demo.post.entity.Post;
import com.example.demo.user.entity.SiteUser;
import jakarta.persistence.Entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private SiteUser requester;  // 요청자

    @ManyToOne
    private Post post;

    @Enumerated(EnumType.STRING)
    private Status status;  // PENDING, ACCEPTED, REJECTED

    @Column(nullable = false)
    private LocalDateTime requestDate;

    @PreUpdate
    public void preUpdate(){
        this.requestDate = LocalDateTime.now();
    }

    public enum Status {
        PENDING, ACCEPTED, REJECTED //대기, 수락, 거절
    }
}
