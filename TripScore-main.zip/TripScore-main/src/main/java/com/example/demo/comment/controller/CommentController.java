package com.example.demo.comment.controller;

import com.example.demo.comment.dto.CommentDto;
import com.example.demo.comment.entity.Comment;
import com.example.demo.comment.service.CommentService;
import com.example.demo.post.entity.Post;
import com.example.demo.post.service.PostService;
import com.example.demo.user.security.SiteUserDetails;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.Comments;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@RequiredArgsConstructor
@Controller
public class CommentController {
    private final PostService postService;
    private final CommentService commentService;

    @PostMapping("/post/detail/{id}")
    public String writeComment(@PathVariable("id") Long id,
                               @Valid @ModelAttribute CommentDto cmtDto,
                               BindingResult bindingResult,
                               @AuthenticationPrincipal SiteUserDetails siteUserDetails,
                               Model model) {
        if (bindingResult.hasErrors()) {
            Post post = postService.findById(id);
            model.addAttribute("post", post);
            model.addAttribute("cmtDto", cmtDto);
            System.out.println("error: " + bindingResult.getAllErrors());
            return "/post/detail";
        }
        // postId는 GET에서 설정해주었으므로 굳이 다시 설정할 필요 없습니다.
        commentService.createComment(cmtDto, siteUserDetails.getUser());
        return "redirect:/post/detail/" + id;
    }
}
