package com.example.demo.comment.controller;

import com.example.demo.comment.dto.CommentDto;
import com.example.demo.comment.entity.Comment;
import com.example.demo.comment.repository.CommentRepository;
import com.example.demo.comment.service.CommentService;
import com.example.demo.post.entity.Post;
import com.example.demo.post.repository.PostImageRepository;
import com.example.demo.post.service.PostService;
import com.example.demo.reservation.entity.Reservation;
import com.example.demo.reservation.repository.ReservationRepository;
import com.example.demo.reservation.service.ReservationService;
import com.example.demo.user.entity.SiteUser;
import com.example.demo.user.security.SiteUserDetails;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Date;
import java.util.Optional;

@RequiredArgsConstructor
@Controller
public class CommentController {
    private final PostService postService;
    private final CommentService commentService;
    private final CommentRepository commentRepository;
    private final ReservationService reservationService;
    private final ReservationRepository reservationRepository;
    private final PostImageRepository postImageRepository;

    @PostMapping("/post/detail/{id}")
    public String writeComment(@PathVariable("id") Long id,
                               @Valid @ModelAttribute("cmtDto") CommentDto cmtDto,
                               BindingResult bindingResult,
                               @AuthenticationPrincipal SiteUserDetails siteUserDetails,
                               Model model) {

        SiteUser user = siteUserDetails.getUser();
        Post post = postService.findById(id);

        // 예약 중 ACCEPTED 상태인 것 중 본인 것이 있는지 확인
        List<Reservation> reservations = reservationRepository.findByPost(post);
        Optional<Reservation> acceptedReservation = reservations.stream()
                .filter(r -> r.getRequester().getId().equals(user.getId()) &&
                        r.getStatus() == Reservation.Status.ACCEPTED &&
                        r.getAcceptedDate() != null)
                .findFirst();

        if (acceptedReservation.isPresent()) {
            Reservation rsv = acceptedReservation.get();
            LocalDate acceptedDate = LocalDate.from(rsv.getAcceptedDate()); // 🔥 여기만 수정
            LocalDate now = LocalDate.now();

            if (now.isBefore(acceptedDate.plusDays(2))) {
                bindingResult.rejectValue("comment", "comment.tooEarly", "댓글은 수락일 기준 2일 후부터 작성할 수 있습니다.");
            }
        } else {
            // ⛔ 수락된 예약이 없으면 댓글 작성 불가
            bindingResult.rejectValue("comment", "comment.notAccepted", "댓글을 작성하려면 예약이 수락되어야 합니다.");
        }

        // ⚠️ 검증 오류 있으면 다시 페이지 렌더링
        if (bindingResult.hasErrors()) {
            model.addAttribute("post", post);
            model.addAttribute("cmtDto", cmtDto);
            model.addAttribute("imageList", postImageRepository.findByPostId(post.getId()));
            model.addAttribute("comments", commentService.getCommentsByPostId(post.getId()));
            model.addAttribute("reservations", reservations);
            return "/post/detail";
        }

        // ✅ 통과했으면 댓글 작성
        commentService.createComment(cmtDto, user);
        return "redirect:/post/detail/" + id;
    }

    @PostMapping("/comment/delete/{id}")
    public String deleteComment(@PathVariable Long id,
                                @AuthenticationPrincipal SiteUserDetails userDetails,
                                HttpServletRequest request) {
        Comment comment = commentService.getCommentId(id);

        // 작성자 본인만 삭제 가능
        if (!comment.getSiteUser().getId().equals(userDetails.getUser().getId())) {
            return "redirect:/"; // or 에러 처리
        }
        System.out.println("whyyyyyyyyyyy?");
        Comment parent = commentRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("댓글이 존재하지 않습니다."));

        List<Comment> children = commentRepository.findByParentComment(parent);
        for (Comment child : children) {
            commentRepository.delete(child);
        }

        Long postId = comment.getPost().getId();
        commentService.deleteComment(id);
        return "redirect:/post/detail/" + postId;
    }
}
