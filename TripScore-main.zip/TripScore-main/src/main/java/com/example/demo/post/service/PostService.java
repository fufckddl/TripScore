package com.example.demo.post.service;

import com.example.demo.post.dto.PostImageDto;
import com.example.demo.post.entity.PostImage;
import com.example.demo.post.repository.PostImageRepository;
import com.example.demo.post.repository.PostRepository;
import com.example.demo.post.dto.PostDto;
import com.example.demo.post.entity.Post;
import com.example.demo.user.entity.SiteUser;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Service
public class PostService {
    private final PostRepository postRepository;
    private final PostImageRepository postImageRepository;

    public void create(PostDto dto, SiteUser user)
    {
        Post post = new Post();
        post.setAddress(dto.getAddress());
        post.setTitle(dto.getTitle());
        post.setContent(dto.getContent());

        post.setSiteUser(user);
        post.setLatitude(dto.getLatitude());
        post.setLongitude(dto.getLongitude());

        postRepository.save(post);
    }
    public void update(Long id, PostDto dto)
    {
        Post post = getpostId(id);
        post.setTitle(dto.getTitle());
        post.setContent(dto.getContent());
        post.setAddress(dto.getAddress());
        post.setLatitude(dto.getLatitude());
        post.setLongitude(dto.getLongitude());
        postRepository.save(post);
    }
    public void uploadImage(PostImageDto dto)
    {
        PostImage postImg = new PostImage();
        postImg.setUrl(dto.getUrl());
        postImageRepository.save(postImg);
    }


    public void delete(Long id)
    {
        postRepository.deleteById(id);
    }
    public List<Post> findAll(){
        return postRepository.findAll();
    }
    public Post findById(Long id)
    {
        return postRepository.findById(id).orElseThrow(()-> new IllegalArgumentException("게시글/숙소를 찾을 수 없습니다."));
    }

    public List<String> fetchAllAddress() {
        List<Post> posts = postRepository.findAll();
        return posts.stream()
                .map(Post::getAddress)     // Post 의 getAddress() 호출
                .collect(Collectors.toList()); //모든 주소를 가져옴 List<String> 형태로
    }

    public List<String> fetchAllTitle() {
        List<Post> posts = postRepository.findAll();
        return posts.stream()
                .map(Post::getTitle)     // Post 의 getAddress() 호출
                .collect(Collectors.toList()); //모든 주소를 가져옴 List<String> 형태로
    }

    public Post getpostId(Long id)
    {
        return postRepository.findById(id).orElseThrow(()-> new RuntimeException("게시글/숙소를 찾을 수 없습니다."));
    }

    //읍/면/동 찾기
    public List<Post> findByTownContaining(String town) {
        return postRepository.findByAddressContaining(town);
    }
}
